using Assignment3;
using Assignment3.Utility;
using System.Runtime.Serialization;
using System.Linq;

namespace Assignment3.Tests
{
    public class SerializationTests
    {
        LinkedList<string> list = new LinkedList<string>();

        private ILinkedListADT users;
        private readonly string testFileName = "test_users.bin";

        [SetUp]
        public void Setup()
        {
            this.users = new SLL();

            users.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            users.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            users.AddLast(new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555"));
            users.AddLast(new User(4, "Ronald McDonald", "burgers4life63@outlook.com", "mcdonalds999"));
        }

        [TearDown]
        public void TearDown()
        {
            this.users.Clear();
            list.Clear();
        }

        /// <summary>
        /// Tests the object was serialized.
        /// </summary>
        [Test]
        public void TestSerialization()
        {
            SerializationHelper.SerializeUsers(users, testFileName);
            Assert.IsTrue(File.Exists(testFileName));
        }

        /// <summary>
        /// Tests the object was deserialized.
        /// </summary>
        [Test]
        public void TestDeSerialization()
        {
            SerializationHelper.SerializeUsers(users, testFileName);
            ILinkedListADT deserializedUsers = SerializationHelper.DeserializeUsers(testFileName);
            
            Assert.IsTrue(users.Count() == deserializedUsers.Count());
            
            for (int i = 0; i < users.Count(); i++)
            {
                User expected = users.GetValue(i);
                User actual = deserializedUsers.GetValue(i);

                Assert.AreEqual(expected.Id, actual.Id);
                Assert.AreEqual(expected.Name, actual.Name);
                Assert.AreEqual(expected.Email, actual.Email);
                Assert.AreEqual(expected.Password, actual.Password);
            }
        }

        [Test]
        public void TestIsEmpty()
        {
            var sll = new SLL();
            bool value = sll.IsEmpty(list);

            Assert.IsTrue(value);
        }

        [Test]
        public void TestPrepended()
        {
            LinkedList<string> listsPre = new LinkedList<string>();
            listsPre.AddFirst("red");
            listsPre.AddFirst("blue");
            
            foreach (string item in listsPre)
            {
                Console.WriteLine(item);
            }

            Assert.AreEqual("blue", listsPre.ElementAt(0));
        }

        [Test]
        public void TestAppended()
        {
            LinkedList<string> lists = new LinkedList<string>();
            lists.AddFirst("blue");
            lists.AddLast("red");

            foreach (string item in lists)
            {
                Console.WriteLine(item);
            }
            
            Assert.AreEqual("red", lists.ElementAt(1));
        }

        [Test]
        public void TestAddAtIndex()
        {
            LinkedList<string> AddAtList = new LinkedList<string>();
            
            AddAtList.AddLast("Purple");
            AddAtList.AddLast("Green");
            LinkedListNode<string> firstNode = AddAtList.AddFirst("Yellow");

            AddAtList.AddAfter(firstNode, "Yellow");

            Assert.IsTrue(AddAtList.Contains("Yellow"));
        }

        [Test]
        public void TestReplace()
        {
            var sll = new SLL();

            LinkedList<string> replaceList = new LinkedList<string>();
            replaceList.AddLast("John");
            
            sll.Replace(replaceList, "John", "Jeff");

            string value = replaceList.ElementAt(0);

            Assert.AreEqual("Jeff", value);
        }

        [Test]
        public void TestRemoveFirst()
        {
            list.AddLast("Bone");
            list.AddLast("Dino");

            list.RemoveFirst();

            Assert.IsFalse(list.Contains("Bone"));
        }

        [Test]
        public void TestRemoveLast()
        {
            list.AddLast("Bone");
            list.AddLast("Dino");
            list.RemoveLast();

            Assert.IsFalse(list.Contains("Dino"));
        }

        [Test]
        public void TestRemoveMiddle()
        {
            LinkedList<string> listMiddle = new LinkedList<string>();
            listMiddle.AddLast("One");
            listMiddle.AddLast("Two");
            listMiddle.AddLast("Three");

            LinkedListNode<string> firstNode = listMiddle.Find("Two");

            listMiddle.Remove(firstNode);

            Assert.IsFalse(listMiddle.Contains("Two"));
        }

        [Test]
        public void TestFoundRetrieved()
        {
            LinkedList<string> listFind = new LinkedList<string>();
            listFind.AddLast("Monday");
            listFind.AddLast("Tuesday");

            string day = listFind.First();

            Assert.AreEqual("Monday", day);
        }

        [Test]
        public void TestReverse()
        {
            list.AddLast("Edmonton");
            list.AddLast("Calgary");
            list.AddLast("Raymond");

            list.Reverse();

            var element = list.ElementAt(2);

            Assert.AreEqual(element, "Raymond");
        }
    }
}