﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.Utility
{
    class Node<T>
    {
        T Data {  get; set; }
        Node<T> Next { get; set; }

        public Node(T data)
        {
            this.Data = data;
            Next = null;
        }
    }
}
