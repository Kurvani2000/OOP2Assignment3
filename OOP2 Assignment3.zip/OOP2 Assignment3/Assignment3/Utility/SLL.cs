﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment3.Utility;

namespace Assignment3.Utility
{
    public class SLL : ILinkedListADT
    {
        public bool IsEmpty(LinkedList<string> list)
        {
            if (list.Count == 0)
            {
                return true;
            }
            else 
            {
                return false;
            }

            throw new NotImplementedException();
        }

        public void Clear()
        {
            
        }

        public void AddLast(User value)
        {
            
        }

        public void AddFirst(User value)
        {
            
        }

        public void Add(User value, int index)
        {
            
        }

        public void Replace(LinkedList<string> list, string currentValue, string newValue)
        {
            list.Find(currentValue).Value = newValue;
        }

        public int Count()
        {
            throw new NotImplementedException();
        }

        public void RemoveFirst()
        {
            
        }

        public void RemoveLast()
        {
            
        }

        public void Remove(int index)
        {
            
        }

        public int IndexOf(LinkedList<string> list, string item)
        {
            var count = 0;
            for (var node = list.First; node != null; node = node.Next, count++)
            {
                if (item.Equals(node.Value))
                {
                    return count;
                }
            }

            throw new NotImplementedException();
        }

        public bool Contains(User value)
        {
            throw new NotImplementedException();
        }

        public LinkedList<string> Reverse(LinkedList<string> list)
        {
            LinkedList<string> copylist = new LinkedList<string>();

            LinkedListNode<string> start = list.Last;

            while (start != null)
            {
                copylist.AddLast(start.Value);
                start = start.Previous;
            }

            list = copylist;
            return list;
        }

        public string ElementAt(int index)
        {
            throw new NotImplementedException();
        }

        public User GetValue(int index)
        {
            throw new NotImplementedException();
        }

        public void Append(string value)
        {
            throw new NotImplementedException();
        }
    }
}
