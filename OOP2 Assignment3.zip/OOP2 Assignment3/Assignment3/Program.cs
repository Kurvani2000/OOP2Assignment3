﻿using Assignment3.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    internal class Program : SLL
    {
        public static void Main(string[] args) 
        {
            var sll = new SLL();

            LinkedList<string> list = new LinkedList<string>(); 

            list.AddFirst("Paris");
            list.AddLast("Calgary");
            list.AddLast("Edmonton");
            list.AddLast("Raymond");

            foreach (string item in list)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("\nIndex of Calgary = " + (sll.IndexOf(list, "Calgary")));

            Console.WriteLine("Value at index 2 is: " + list.ElementAt(2));

            Console.WriteLine("\nReversing...");
            list = sll.Reverse(list);

            foreach (string item in list)
            {
                Console.WriteLine(item);
            }
            
            Console.WriteLine("\nRemoving first and last...");

            list.RemoveFirst();
            list.RemoveLast();

            foreach (string item in list)
            {
                Console.WriteLine(item);
            }

            //need add
            //need 'remove an item at a specific index'
            
            Console.WriteLine("\nList Count: " + list.Count());

            list.Clear();

            Console.WriteLine("List empty: " + sll.IsEmpty(list));

            foreach (string item in list)
            {
                Console.WriteLine(item);
            }

            Console.ReadLine();
        }
    }
}
